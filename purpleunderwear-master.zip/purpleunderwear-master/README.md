Purple Underwear
============
Open the index.html file in a modern browser.

All css should be done in main.css

All JavaScript should be done in app.js
